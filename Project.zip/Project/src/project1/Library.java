package project1;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class Library extends JFrame implements ActionListener {
	JButton btnBs, btnCl, btnUs, btnUn;
	String[][] bdatas = new String[0][7];
	String[] btitles = { "도서번호", "도서명", "저자명", "출판사", "출판년도", "대여여부", "이용자번호" };
	DefaultTableModel model = new DefaultTableModel(bdatas, btitles);
	JTable table = new JTable(model);
	JTextField txtbno, txtbname, txtwname, txtbcom, txtbyear, txtuno;

	Connection conn;
	PreparedStatement pstmt;
	ResultSet rs;

	public Library() {
		super("도서정보관리시스템");

		layInit();
		accDb();

		setResizable(true);
		setBounds(400, 400, 1000, 500);
		setVisible(true);

		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				int re = JOptionPane.showConfirmDialog(Library.this, "정말 종료할까요?", "종료", JOptionPane.OK_CANCEL_OPTION);
				if (re == JOptionPane.OK_OPTION) {
					try {
						if (rs != null)
							rs.close();
						if (conn != null)
							conn.close();
						if (pstmt != null)
							pstmt.close();
					} catch (Exception e2) {
						System.out.println("windowClosing err :" + e);
					}
					System.exit(0);
				} else {
					setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
				}
			}
		});

	}

	private void layInit() {
		// 1 north 검색
		JLabel lbl1 = new JLabel("도서번호 : ", JLabel.LEFT);
		txtbno = new JTextField("", 5);
		JLabel lbl2 = new JLabel("도서명 : ", JLabel.LEFT);
		txtbname = new JTextField("", 5);
		JLabel lbl3 = new JLabel("저자명 : ", JLabel.LEFT);
		txtwname = new JTextField("", 5);
		JLabel lbl4 = new JLabel("출판사 : ", JLabel.LEFT);
		txtbcom = new JTextField("", 5);
		JLabel lbl5 = new JLabel("출판년도 : ", JLabel.LEFT);
		txtbyear = new JTextField("", 5);
		JLabel lbl6 = new JLabel("이용자번호 : ", JLabel.LEFT);
		txtuno = new JTextField("", 5);
		btnBs = new JButton("검색"); // 도서검색버튼
		btnBs.setBackground(Color.WHITE);
		btnBs.addActionListener(this);
		btnCl = new JButton("초기화"); // 도서검색 초기화
		btnCl.setBackground(Color.WHITE);
		btnCl.addActionListener(this);

		JPanel pn1 = new JPanel();
		pn1.add(lbl1);
		pn1.add(txtbno);
		pn1.add(lbl2);
		pn1.add(txtbname);
		pn1.add(lbl3);
		pn1.add(txtwname);
		pn1.add(lbl4);
		pn1.add(txtbcom);
		pn1.add(lbl5);
		pn1.add(txtbyear);
		pn1.add(lbl6);
		pn1.add(txtuno);
		pn1.add(btnBs);
		pn1.add(btnCl);
		add("North", pn1);

		// 2 center 리스트
		table.getColumnModel();
		JScrollPane scl = new JScrollPane(table);
		add("Center", scl);

		// 3 south
		JLabel lbl7 = new JLabel("이용자번호 : ", JLabel.LEFT);
		txtuno = new JTextField("", 5);
		btnUs = new JButton("조회");
		btnUs.setBackground(Color.WHITE);
		btnUs.addActionListener(this);
		btnUn = new JButton("신규");
		btnUn.setBackground(Color.WHITE);
		btnUn.addActionListener(this);

		JPanel pn2 = new JPanel();
		pn2.add(lbl7);
		pn2.add(txtuno);
		pn2.add(btnUs);
		pn2.add(btnUn);
		add("South", pn2);

	}

	private void accDb() {
		try {
			Class.forName("org.mariadb.jdbc.Driver");
			// 자료가 실행하자마자 보여지기
			dispData();
		} catch (Exception e) {
			System.out.println("accDb err : " + e);
		}
	}

	private void dispData() {
		model.setNumRows(0);
		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "123");
			String sql = "SELECT bno, bname, wname, bcom, byear, nvl2(uno, 'O', 'X') AS 대여여부, bookinfo_uno\r\n"
					+ "FROM bookinfo\r\n" + "LEFT OUTER JOIN userinfo on bookinfo_uno = uno";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery(sql);

			while (rs.next()) {
				String[] binfo = { rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5),
						rs.getString(6), rs.getString(7) };
				model.addRow(binfo);
			}
		} catch (Exception e) {
			System.out.println("dispData err :" + e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (conn != null)
					conn.close();
				if (pstmt != null)
					pstmt.close();

			} catch (Exception e2) {
				System.out.println("dispData1 err :" + e2);
			}
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btnBs) { // 도서검색
			try {
				
				conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "123");
				String sql = "SELECT bno, bname, wname, bcom, byear, nvl2(uno, 'O', 'X') AS 대여여부, bookinfo_uno\r\n"
						+ "FROM bookinfo\r\n" + "LEFT OUTER JOIN userinfo on bookinfo_uno = uno where bno =?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, Integer.parseInt(txtbno.getText()));
				rs = pstmt.executeQuery();
				model.setNumRows(0);
				
				while (rs.next()) {
					String[] binfo = { rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5),
							rs.getString(6), rs.getString(7) };
					model.addRow(binfo);
				}
				
				
			} catch (Exception e2) {
				System.out.println("btnBs err :" + e);
			}finally {
				try {
					if (rs != null)
						rs.close();
					if (pstmt != null)
						pstmt.close();
					if (conn != null)
						conn.close();
				} catch (Exception e2) {

				}
			}

		} else if (e.getSource() == btnCl) { // 입력값 초기화
			txtbno.setText("");
			txtbname.setText("");
			txtwname.setText("");
			txtbcom.setText("");
			txtbyear.setText("");
			txtuno.setText("");
			txtbno.requestFocus(); // 도서넘버로 초기화
			return;
		} else if (e.getSource() == btnUs) { // 이용자검색

		} else if (e.getSource() == btnUn) { // 이용자신규

		}

	}

	public static void main(String[] args) {
		new Library();

	}

}
